Hello Professor,

	I am the student of Ios app development course, this is the readme file  for my final capstone project.
 In my project, I developed a small app based on home remedies, In this app, the first page will be 
 a tableview which shows all the problems like fever, asthma etc, when person clicks, the person can see the remedies for that 
 problem. Moreover , the person can add their own remedies for any problem they know. Person can also add the comment for any 
 method for problem and can also see the previous comments.
 
 now, for second thing I don't have any error so far in my xcode.
 
 From
 Charmy