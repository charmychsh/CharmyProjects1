//
//  SaveCommentViewController.m
//  Remedies
//
//  Created by Charmy Shah on 12/6/14.
//  Copyright (c) 2014 charmy shah. All rights reserved.
//

#import "SaveCommentViewController.h"
#import <Parse/Parse.h>

@interface SaveCommentViewController ()

@end

@implementation SaveCommentViewController
@synthesize commentTextView;
@synthesize commentButton;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self CommentTextViewBorder];
    [self CommentButtonBorder];
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"images.jpg"]];
    
    
}



-(void)CommentButtonBorder
{
    commentButton.layer.cornerRadius = 10;
    commentButton.layer.borderWidth = 1;
    commentButton.layer.borderColor = [UIColor grayColor].CGColor;
    [commentButton.layer setBackgroundColor: [[UIColor brownColor] CGColor]];
}


-(void)CommentTextViewBorder
{
    
    
    [self.commentTextView.layer setBackgroundColor: [[UIColor whiteColor] CGColor]];
    [self.commentTextView.layer setBorderColor: [[UIColor grayColor] CGColor]];
    [self.commentTextView.layer setBorderWidth: 1.5];
    [self.commentTextView.layer setCornerRadius:9.0f];
    [self.commentTextView.layer setMasksToBounds:YES];
    NSLog(@"data is %@",partMethod);
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)saveComment:(id)sender {
    td = commentTextView.text;
    PFObject *commentData = [PFObject objectWithClassName: partMethod];
    [commentData setObject:td forKey:@"comment"];
    
    [commentData saveInBackgroundWithBlock:^(BOOL succeeded, NSError *error) {
        //  [hud hide:YES];
        
        if (!error) {
            // Show success message
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Upload Complete" message:@"Successfully saved the method" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            [alert show];
            
            // Notify table view to reload the recipes from Parse cloud
            [[NSNotificationCenter defaultCenter] postNotificationName:@"refreshTable" object:self];
            
            // Dismiss the controller
            [self dismissViewControllerAnimated:YES completion:nil];
            
        } else {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Upload Failure" message:[error localizedDescription] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            [alert show];
            
        }
        
    }];

    
}

#pragma - textview delegate

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
    
}

@end
