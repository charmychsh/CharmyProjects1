Hello Professor,

	My name is Charmy Shah, RedId:818556148. 

	My project name is ParseExample and application is named as HOMEREMEDIES. This app is based on the use of Parse database. Once the app is started to run, first comes the splash screen followed by MainActivty which is the list of all problems which are stored in data base. When person selects the problem for search of remedies, the person can see few different methodnames. Once person select particular methodname then person see detail method along with the comments for that method, person can also add comment by clicking button for “AddComment”. In the activity where there is list of methodnames, there is a actionbar which has two button named “Refresh” and “Add”. When click on add button, person can also add their own method, refresh button will refresh the activity and also add new method if added by someone. If person try to save method or comment without entering any data , an dialog box pop up with message. In DataActivity, new comment will be not seen directly , person had to go back and again come to that method data.  

	I have used Parse SDK, for storing data in parse database. The link for downloading SDK is https://www.parse.com/downloads/android/Parse/latest. Copy the Parse-x.x.x.jar file from your extracted download into your libs folder and also add the dependency in the build.gradle file.

	I had problem with gradle on last day of submission, I solved the error but gradle is not building(compiling) project in my software, there is no error but just its not building.The app works fine till last time it built, I wanted to add the refresh button in action bar in DataActivity but couldn’t do so due to problem of gradle , I figured its problem of software. I tried but cannot find the problem, I hope that will not be a problem in your software. 

 
