//
//  SaveCommentViewController.h
//  Remedies
//
//  Created by Charmy Shah on 12/6/14.
//  Copyright (c) 2014 charmy shah. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Parse/Parse.h>

@interface SaveCommentViewController : UIViewController<UITextViewDelegate> {
   @public NSString *partMethod;
    NSString *td;
}
@property (strong, nonatomic) IBOutlet UITextView *commentTextView;
@property (strong, nonatomic) IBOutlet UIButton *commentButton;

- (IBAction)saveComment:(id)sender;
-(void)CommentTextViewBorder;
-(void)CommentButtonBorder;

@end
