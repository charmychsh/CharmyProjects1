//
//  DetailViewController.h
//  Remedies
//
//  Created by Charmy Shah on 12/6/14.
//  Copyright (c) 2014 charmy shah. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Parse/Parse.h>

@interface DetailViewController : UIViewController<UITableViewDataSource,UITableViewDelegate> {
    
    @public NSObject *detailData;
    NSArray *comments;
    NSString *particularMethod;
}
@property (strong, nonatomic) IBOutlet UIView *headerView;

@property (strong, nonatomic) IBOutlet UITableView *myTableView;
@property (strong, nonatomic) IBOutlet UILabel *dataLabel;
@property (nonatomic,strong) NSString *methodName;
@end
