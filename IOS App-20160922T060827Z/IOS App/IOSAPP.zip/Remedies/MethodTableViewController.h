//
//  MethodTableViewController.h
//  Remedies
//
//  Created by Charmy Shah on 11/26/14.
//  Copyright (c) 2014 charmy shah. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MethodTableViewController : UITableViewController{
    NSArray *cough;
    NSArray *dandruff;
    NSArray *fever;

    
}

@property (nonatomic,strong) NSString *problemName;
@end

