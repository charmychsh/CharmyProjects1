//
//  SaveMethodViewController.m
//  Remedies
//
//  Created by Charmy Shah on 12/6/14.
//  Copyright (c) 2014 charmy shah. All rights reserved.
//

#import "SaveMethodViewController.h"
#import <Parse/Parse.h>

@interface SaveMethodViewController ()

@end

@implementation SaveMethodViewController
@synthesize myTextView;
@synthesize myButton;
@synthesize myTextField;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self textViewBorder];
    [self buttonBorder];
    [self textBorder];
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"images.jpg"]];
}

-(void)buttonBorder
{
    myButton.layer.cornerRadius = 10;
    myButton.layer.borderWidth = 1;
    myButton.layer.borderColor = [UIColor grayColor].CGColor;
    [myButton.layer setBackgroundColor: [[UIColor brownColor] CGColor]];
}


-(void)textViewBorder
{
    [self.myTextView.layer setBackgroundColor: [[UIColor whiteColor] CGColor]];
    [self.myTextView.layer setBorderColor: [[UIColor grayColor] CGColor]];
    [self.myTextView.layer setBorderWidth: 1.5];
    [self.myTextView.layer setCornerRadius:9.0f];
    [self.myTextView.layer setMasksToBounds:YES];
}

-(void)textBorder
{
    [self.myTextField.layer setBackgroundColor: [[UIColor whiteColor] CGColor]];
    [self.myTextField.layer setBorderColor: [[UIColor grayColor] CGColor]];
    [self.myTextField.layer setBorderWidth: 1.5];
    [self.myTextField.layer setCornerRadius:9.0f];
    [self.myTextField.layer setMasksToBounds:YES];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)saveData:(id)sender {
    
    PFObject *newData = [PFObject objectWithClassName:@"method"];
    [newData setObject:myTextField.text forKey:@"methodName"];
    [newData setObject:myTextView.text forKey:@"method"];
    
    [newData saveInBackgroundWithBlock:^(BOOL succeeded, NSError *error) {
        //  [hud hide:YES];
        
        if (!error) {
            // Show success message
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Upload Complete" message:@"Successfully saved the method" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            [alert show];
            
            // Notify table view to reload the recipes from Parse cloud
            [[NSNotificationCenter defaultCenter] postNotificationName:@"refreshTable" object:self];
            
            // Dismiss the controller
            [self dismissViewControllerAnimated:YES completion:nil];
            
        } else {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Upload Failure" message:[error localizedDescription] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            [alert show];
            
        }
        
    }];
 /*
    PFObject *newCommentData = [PFObject objectWithClassName: myTextField.text];
    [newCommentData setObject:@"add comments.." forKey: @"comment"];
    NSLog(@"GOES HERE");
    [newData saveInBackgroundWithBlock:^(BOOL succeeded, NSError *error) {
        //  [hud hide:YES];
        
        if (!error) {
            // Show success message
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Upload Complete" message:@"Successfully saved the method" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            [alert show];
            
            // Notify table view to reload the recipes from Parse cloud
            [[NSNotificationCenter defaultCenter] postNotificationName:@"refreshTable" object:self];
            
            // Dismiss the controller
            [self dismissViewControllerAnimated:YES completion:nil];
            
        } else {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Upload Failure" message:[error localizedDescription] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            [alert show];
            
        }
        
    }];*/
    
    
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if([segue.identifier isEqualToString:@"commentDetail"]){
        SaveCommentViewController *destViewController = segue.destinationViewController;
        destViewController = [segue destinationViewController];
        destViewController.partMethod = 
    }
}*/



#pragma - textview delegate

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
    
}

@end
