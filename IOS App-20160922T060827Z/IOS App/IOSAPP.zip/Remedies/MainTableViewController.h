//
//  MainTableViewController.h
//  Remedies
//
//  Created by Charmy Shah on 11/26/14.
//  Copyright (c) 2014 charmy shah. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainTableViewController : UITableViewController {
     NSArray *methods;
}

@end
