//
//  SaveMethodViewController.h
//  Remedies
//
//  Created by Charmy Shah on 12/6/14.
//  Copyright (c) 2014 charmy shah. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Parse/Parse.h>

@interface SaveMethodViewController : UIViewController<UITextViewDelegate>{
    NSString *td;
}
@property (strong, nonatomic) IBOutlet UITextField *myTextField;
@property (strong, nonatomic) IBOutlet UITextView *myTextView;
@property (strong, nonatomic) IBOutlet UIButton *myButton;

- (IBAction)saveData:(id)sender;
-(void)textViewBorder;
-(void)buttonBorder;
-(void)textBorder;
@end
