//
//  MethodTableViewController.m
//  Remedies
//
//  Created by Charmy Shah on 11/26/14.
//  Copyright (c) 2014 charmy shah. All rights reserved.
//

#import "MethodTableViewController.h"
#import "DetailViewController.h"

@interface MethodTableViewController ()

@end

@implementation MethodTableViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    cough = [NSArray arrayWithObjects:@"method1",@"method2",@"method3",@"method4", nil];
     dandruff = [NSArray arrayWithObjects:@"method1",@"method2",@"method3",@"method4", nil];
     fever = [NSArray arrayWithObjects:@"method1",@"method2",@"method3",@"method4", nil];
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if([_problemName isEqualToString:@"cough"]){
        return cough.count;
    }
    else if([_problemName isEqualToString:@"dandruff"]){
        return dandruff.count;
    }
    else 
        return fever.count;
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleIdentifier = @"problem2Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleIdentifier];
    
    if (cell == nil){
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleIdentifier];
    }
    if([_problemName isEqualToString:@"cough"]){
         cell.textLabel.text = [cough objectAtIndex:indexPath.row];
    }
    else if([_problemName isEqualToString:@"dandruff"]){
        cell.textLabel.text = [dandruff objectAtIndex:indexPath.row];
    }
    else if([_problemName isEqualToString:@"fever"]){
        cell.textLabel.text = [fever objectAtIndex:indexPath.row];
    }
    
     cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


#pragma mark - Navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if([segue.identifier isEqualToString:@"detailData"]){
        
        DetailViewController *DVC = [[DetailViewController alloc] init];
        DVC = [segue destinationViewController];
        NSIndexPath *path = [self.tableView indexPathForSelectedRow];
        DVC.title = [cough objectAtIndex:path.row];
        NSLog(@"data id %@",[cough objectAtIndex:path.row]);
    //    DVC.detailData = [result objectAtIndex:path.row];
       
    }
}


@end
