//
//  DetailViewController.m
//  Remedies
//
//  Created by Charmy Shah on 12/6/14.
//  Copyright (c) 2014 charmy shah. All rights reserved.
//

#import "DetailViewController.h"
#import "SaveCommentViewController.h"
#import <Parse/Parse.h>

@interface DetailViewController ()

@end

@implementation DetailViewController
@synthesize myTableView;
@synthesize headerView;
@synthesize dataLabel;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSString *data = [(NSDictionary*)detailData objectForKey:@"method"];
    dataLabel.text = data;
    particularMethod = [(NSDictionary*)detailData objectForKey:@"methodName"];
    headerView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"images.jpg"]];
    
    UIImage *background = [UIImage imageNamed:@"new.jpg"];
    UIImageView *imageView = [[UIImageView alloc] initWithImage:background];
    [self.myTableView setBackgroundView:imageView];
    
     [self performSelector:@selector(retrieveFromParse)];
    [myTableView reloadData];

}

- (void)tableView:(UITableView *)tableView
  willDisplayCell:(UITableViewCell *)cell
forRowAtIndexPath:(NSIndexPath *)indexPath
{
    [cell setBackgroundColor:[UIColor clearColor]];
}




-(void) retrieveFromParse {
    PFQuery *retrieveMethod = [PFQuery queryWithClassName:particularMethod];
    [retrieveMethod findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
        
       // NSLog(@"data is %@",objects);
        if(!error){
            comments = [[NSArray alloc] initWithArray:objects];
        }
        [myTableView reloadData];
    }];
    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
        return comments.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleIdentifier = @"problem2Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleIdentifier];
    
    if (cell == nil){
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleIdentifier];
    }
    
    PFObject *tempNewObject = [comments objectAtIndex:indexPath.row];
    NSString *newAddress = [NSString stringWithFormat:@"%@", [tempNewObject objectForKey: @"comment"]];
    // cell.textLabel.text = [tempObject objectForKey:@"methodName"];
    cell.textLabel.text = newAddress;

    
    return cell;
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if([segue.identifier isEqualToString:@"commentDetail"]){
        SaveCommentViewController *destViewController = segue.destinationViewController;
        destViewController = [segue destinationViewController];
        destViewController->partMethod = particularMethod;
    }

}


@end
