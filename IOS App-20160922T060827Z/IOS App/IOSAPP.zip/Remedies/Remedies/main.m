//
//  main.m
//  Remedies
//
//  Created by Charmy Shah on 11/26/14.
//  Copyright (c) 2014 charmy shah. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
